<?php

namespace App\Http\Controllers\WQS;

use App\Http\Controllers\Controller;
use App\Models\SalesDO;
use App\Models\TaskBoard;
use App\Models\WQSStockCheck;
use App\Models\WQSStockCheckItem;
use App\Models\Product;
use App\Services\AuditLogService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\DB;

class StockCheckController extends Controller implements HasMiddleware
{
    protected $auditLog;

    public function __construct(AuditLogService $auditLog)
    {
        $this->auditLog = $auditLog;
    }

    public static function middleware(): array
    {
        return [
            new Middleware('permission:wqs.view', only: ['index', 'show']),
            new Middleware('permission:process_wqs', only: ['create', 'store', 'update', 'destroy']),
        ];
    }

    /**
     * Display stock checks list
     */
    public function index(Request $request)
    {
        $query = WQSStockCheck::with([
            'salesDO',
            'salesDO.customer',
            'salesDO.office',
            'checkedBy',
            'items',
        ]);

        /* ============================
        FILTERS
        ============================ */
        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('salesDO', function($q) use ($search) {
                $q->where('do_code', 'like', "%{$search}%")
                  ->orWhereHas('customer', function($q) use ($search) {
                      $q->where('name', 'like', "%{$search}%");
                  });
            });
        }

        if ($request->filled('status')) {
            $query->byStatus($request->status);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('check_date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('check_date', '<=', $request->date_to);
        }

        $stockChecks = $query->latest('check_date')->paginate(15);

        // foreach($stockChecks as $stockCheck) {
        //     dd($stockCheck->salesDO->id);
        // }

        $tasks = WQSStockCheck::with([
            'salesDO.customer',
            'salesDO.office',
            'checkedBy',
            'items',
        ])
            ->byStatus('pending')
            ->latest('check_date')
            ->paginate(10);

        /* ============================
        STATISTICS
        ============================ */
        $stats = [
            'pending' => WQSStockCheck::pending()->count(),
            'checked' => WQSStockCheck::checked()->count(),
            'completed' => WQSStockCheck::completed()->count(),
            'failed' => WQSStockCheck::failed()->count(),
        ];

        return view('pages.wqs.stock_checks.index', compact('stockChecks','tasks','stats'));
    }

    /**
     * Show stock check form for DO
     */
    public function create(Request $request)
    {
        $salesDo = SalesDO::with(['items.product', 'customer', 'office'])
                         ->findOrFail($request->sales_do_id);

        // Verify DO is in WQS stage
        if (!in_array($salesDo->status, ['crm_to_wqs', 'wqs_ready', 'wqs_on_hold'])) {
            return redirect()
                ->route('wqs.task-board.index')
                ->with('error', 'This DO is not in WQS stage.');
        }

        // Check if stock check already exists
        $existingCheck = WQSStockCheck::where('sales_do_id', $salesDo->id)
                                      ->where('overall_status', '!=', 'failed')
                                      ->exists();

        if ($existingCheck) {
            return redirect()
                ->route('wqs.stock-checks.show', ['stock_check' => $existingCheck])
                ->with('info', 'Stock check already exists for this DO.');
        }

        return view('pages.wqs.stock_checks.create', compact('salesDo'));
    }

    /**
     * Store stock check record
     */
    public function store(Request $request)
    {

        $validated = $request->validate([
            'sales_do_id' => 'required|exists:sales_do,id',
            'check_notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:master_products,id',
            'items.*.stock_status' => 'required|in:available,partial,not_available',
            'items.*.available_qty' => 'required|integer|min:0',
            'items.*.notes' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $salesDo = SalesDO::findOrFail($validated['sales_do_id']);

            // Create stock check record
            $stockCheck = WQSStockCheck::create([
                'sales_do_id' => $salesDo->id,
                'check_date' => today(),
                'overall_status' => 'checked',
                'check_notes' => $validated['check_notes'],
                'checked_by' => auth()->id(),
            ]);

            // Add items to stock check
            foreach ($validated['items'] as $itemData) {
                WQSStockCheckItem::create([
                    'stock_check_id' => $stockCheck->id,
                    'product_id' => $itemData['product_id'],
                    'stock_status' => $itemData['stock_status'],
                    'available_qty' => $itemData['available_qty'],
                    'notes' => $itemData['notes'] ?? '',
                ]);
            }

            // Determine overall status
            $allAvailable = collect($validated['items'])
                ->every(fn($item) => $item['stock_status'] === 'available');

            if ($allAvailable) {
                $stockCheck->markCompleted();
                $salesDo->update(['status' => 'scm_on_delivery']);
                $status = 'completed';
            } else {
                $problematicItems = $stockCheck->getProblematicItems();
                $salesDo->update(['status' => 'wqs_on_hold']);
                $status = 'on_hold';
            }

            // Create/Update task
            $task = TaskBoard::where('sales_do_id', $salesDo->id)
                             ->where('module', 'wqs')
                             ->where('task_type', 'wqs_stock_check')
                             ->first();

            if ($task) {
                $task->update(['task_status' => 'completed']);
            } else {
                TaskBoard::create([
                    'sales_do_id' => $salesDo->id,
                    'module' => 'wqs',
                    'task_type' => 'wqs_stock_check',
                    'task_status' => 'completed',
                    'task_description' => 'Stock Check for DO ' . $salesDo->do_code,
                    'priority' => 'high',
                    'due_date' => now(),
                    'created_by' => auth()->id(),
                ]);
            }

            // Audit log
            $this->auditLog->log('WQS_STOCK_CHECK_CREATED', 'WQS', [
                'stock_check_id' => $stockCheck->id,
                'do_code' => $salesDo->do_code,
                'items_count' => count($validated['items']),
                'overall_status' => $status,
            ]);

            DB::commit();

            $message = $allAvailable
                ? 'Stock check completed - All items available. Proceeding to delivery.'
                : 'Stock check completed - Some items unavailable. DO placed on hold.';

            return redirect()
                ->route('wqs.stock-checks.show', $stockCheck)
                ->with('success', $message);

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->with('error', 'Failed to create stock check: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Show stock check details
     */
    public function show(WQSStockCheck $stockCheck)
    {
        $stockCheck->load([
            'salesDO.customer',
            'salesDO.office',
            'salesDO.items.product',
            'checkedBy',
            'items.product',
            'documents',
        ]);

        return view('pages.wqs.stock_checks.show', compact('stockCheck'));
    }

    /**
     * Edit stock check (if not completed)
     */
    public function edit(WQSStockCheck $stockCheck)
    {
        if ($stockCheck->overall_status === 'completed') {
            return redirect()
                ->route('wqs.stock-checks.show', $stockCheck)
                ->with('error', 'Cannot edit completed stock check.');
        }

        $stockCheck->load([
            'salesDO.items.product',
            'items.product',
        ]);

        return view('pages.wqs.stock_checks.edit', compact('stockCheck'));
    }

    /**
     * Update stock check record
     */
    public function update(Request $request, WQSStockCheck $stockCheck)
    {
        if ($stockCheck->overall_status === 'completed') {
            return redirect()
                ->back()
                ->with('error', 'Cannot update completed stock check.');
        }

        $validated = $request->validate([
            'check_notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.stock_check_item_id' => 'nullable|exists:wqs_stock_check_items,id',
            'items.*.product_id' => 'required|exists:master_products,id',
            'items.*.stock_status' => 'required|in:available,partial,not_available',
            'items.*.available_qty' => 'required|integer|min:0',
            'items.*.notes' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            // Update check notes
            $stockCheck->update([
                'check_notes' => $validated['check_notes'],
            ]);

            // Update items
            $existingItemIds = [];
            foreach ($validated['items'] as $itemData) {
                if ($itemData['stock_check_item_id']) {
                    // Update existing
                    $item = WQSStockCheckItem::findOrFail($itemData['stock_check_item_id']);
                    $item->update([
                        'stock_status' => $itemData['stock_status'],
                        'available_qty' => $itemData['available_qty'],
                        'notes' => $itemData['notes'] ?? '',
                    ]);
                    $existingItemIds[] = $item->id;
                } else {
                    // Create new
                    $item = WQSStockCheckItem::create([
                        'stock_check_id' => $stockCheck->id,
                        'product_id' => $itemData['product_id'],
                        'stock_status' => $itemData['stock_status'],
                        'available_qty' => $itemData['available_qty'],
                        'notes' => $itemData['notes'] ?? '',
                    ]);
                    $existingItemIds[] = $item->id;
                }
            }

            // Delete removed items
            $stockCheck->items()
                       ->whereNotIn('id', $existingItemIds)
                       ->delete();

            // Re-evaluate overall status
            $allAvailable = $stockCheck->items()
                ->where('stock_status', 'available')
                ->count() === $stockCheck->items()->count();

            if ($allAvailable && $stockCheck->isFullyChecked()) {
                $stockCheck->markCompleted();
                $stockCheck->salesDO->update(['status' => 'scm_on_delivery']);
            } else {
                $stockCheck->update(['overall_status' => 'checked']);
                $stockCheck->salesDO->update(['status' => 'wqs_on_hold']);
            }

            // Audit log
            $this->auditLog->log('WQS_STOCK_CHECK_UPDATED', 'WQS', [
                'stock_check_id' => $stockCheck->id,
                'do_code' => $stockCheck->salesDO->do_code,
            ]);

            DB::commit();

            return redirect()
                ->route('wqs.stock-checks.show', $stockCheck)
                ->with('success', 'Stock check updated successfully.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->with('error', 'Failed to update stock check: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Mark stock check as failed
     */
    public function markFailed(Request $request, WQSStockCheck $stockCheck)
    {
        $validated = $request->validate([
            'reason' => 'required|string',
            'problematic_items' => 'nullable|array',
        ]);

        DB::beginTransaction();
        try {
            // Update stock check status
            $stockCheck->update([
                'overall_status' => 'failed',
                'failed_reason' => $validated['reason'],
                'checked_at' => now(),
            ]);

            // Update Sales DO status to on hold
            $stockCheck->salesDO->update([
                'status' => 'wqs_on_hold',
            ]);

            // Get problematic items
            $problematicItems = $stockCheck->items()
                ->where('check_status', '!=', 'pass')
                ->with('product')
                ->get()
                ->map(function ($item) {
                    return [
                        'product_id' => $item->product_id,
                        'product_name' => $item->product_name,
                        'product_sku' => $item->product_sku,
                        'qty_ordered' => $item->qty_ordered,
                        'qty_available' => $item->qty_available,
                        'qty_shortage' => $item->qty_ordered - $item->qty_available,
                        'check_status' => $item->check_status,
                    ];
                })
                ->toArray();

            $this->auditLog->log('STOCK_CHECK_FAILED', 'WQS', [
                'stock_check_id' => $stockCheck->id,
                'do_code' => $stockCheck->salesDO->do_code,
                'reason' => $validated['reason'],
                'problematic_items_count' => count($problematicItems),
            ]);

            // *** ADD THIS: Dispatch StockCheckFailed event ***
            event(new StockCheckFailed($stockCheck, $problematicItems));

            DB::commit();

            return redirect()
                ->route('wqs.stock-checks.show', $stockCheck)
                ->with('warning', 'Stock check marked as failed. Procurement team has been notified.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->with('error', 'Failed to mark stock check as failed: ' . $e->getMessage());
        }
    }

    /**
     * Delete stock check (only if not completed)
     */
    public function destroy(WQSStockCheck $stockCheck)
    {
        if ($stockCheck->overall_status === 'completed') {
            return redirect()
                ->back()
                ->with('error', 'Cannot delete completed stock check.');
        }

        $doCode = $stockCheck->salesDO->do_code;
        $stockCheck->delete();

        $this->auditLog->log('WQS_STOCK_CHECK_DELETED', 'WQS', [
            'do_code' => $doCode,
        ]);

        return redirect()
            ->route('wqs.stock-checks.index')
            ->with('success', 'Stock check deleted.');
    }

    /**
     * Get problematic items in stock check
     */
    public function getProblematicItems(WQSStockCheck $stockCheck)
    {
        $items = $stockCheck->items()
            ->where('check_status', '!=', 'pass')
            ->with('product')
            ->get()
            ->map(function ($item) {
                return [
                    'product_name' => $item->product_name,
                    'product_sku' => $item->product_sku,
                    'qty_ordered' => $item->qty_ordered,
                    'qty_available' => $item->qty_available,
                    'qty_shortage' => $item->qty_ordered - $item->qty_available,
                    'check_status' => $item->check_status,
                    'remarks' => $item->remarks,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $items,
        ]);
    }


     public function approve(Request $request, WQSStockCheck $stockCheck)
    {
        $validated = $request->validate([
            'notes' => 'nullable|string',
        ]);

        // Validate all items have passed
        $failedItems = $stockCheck->items()
            ->where('check_status', '!=', 'pass')
            ->count();

        if ($failedItems > 0) {
            return redirect()
                ->back()
                ->with('error', 'Cannot approve. Some items have not passed the check.');
        }

        DB::beginTransaction();
        try {
            $stockCheck->update([
                'overall_status' => 'completed',
                'approved_by' => Auth::id(),
                'approved_at' => now(),
                'notes' => $validated['notes'] ?? null,
            ]);

            // Reserve inventory for these items
            foreach ($stockCheck->items as $item) {
                // Reduce available stock
                $product = $item->product;
                $product->decrement('stock_quantity', $item->qty_ordered);

                // Or use inventory service
                // app(InventoryManagementService::class)
                //     ->reserveStock($item->product_id, $item->qty_ordered, $stockCheck->salesDO->id);
            }

            $this->auditLog->log('STOCK_CHECK_APPROVED', 'WQS', [
                'stock_check_id' => $stockCheck->id,
                'do_code' => $stockCheck->salesDO->do_code,
                'approved_by' => Auth::user()->name,
            ]);

            DB::commit();

            return redirect()
                ->route('wqs.stock-checks.show', $stockCheck)
                ->with('success', 'Stock check approved successfully.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->with('error', 'Failed to approve stock check: ' . $e->getMessage());
        }
    }

    /**
     * Generate stock check report
     */
    public function generateReport(WQSStockCheck $stockCheck)
    {
        $report = $stockCheck->getReport();

        return response()->json([
            'success' => true,
            'data' => $report,
        ]);
    }
}
