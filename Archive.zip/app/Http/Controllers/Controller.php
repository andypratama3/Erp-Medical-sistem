<?php

namespace App\Http\Controllers;

use App\Helpers\ApiResponse;


abstract class Controller
{
    //
    use ApiResponse;
}
