# Views

Place reusable components here

Use reference from provided blade files.