# Views

Place layout files here (app.blade.php, sidebar.blade.php, navigation.blade.php)

Use reference from provided blade files.