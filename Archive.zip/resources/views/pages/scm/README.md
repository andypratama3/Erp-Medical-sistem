# Views

SCM module views (deliveries, task_board)

Use reference from provided blade files.