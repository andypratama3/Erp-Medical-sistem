# Views

WQS module views (task_board, stock_check)

Use reference from provided blade files.