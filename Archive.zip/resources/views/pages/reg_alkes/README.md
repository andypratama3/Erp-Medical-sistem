# Views

REG ALKES module views (control_tower, cases, import_sku)

Use reference from provided blade files.