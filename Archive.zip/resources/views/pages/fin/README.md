# Views

FIN module views (collections, aging, task_board)

Use reference from provided blade files.