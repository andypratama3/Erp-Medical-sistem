# Views

ACT module views (invoices, task_board)

Use reference from provided blade files.