# Views

Master data views (offices, departments, products, etc)

Use reference from provided blade files.