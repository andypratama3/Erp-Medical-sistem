# Views

CRM module views (sales_do)

Use reference from provided blade files.