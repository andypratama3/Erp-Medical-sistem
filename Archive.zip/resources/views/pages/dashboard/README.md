# Views

Dashboard views

Use reference from provided blade files.